package game;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import javax.swing.JFrame;

import entity.mob.Player;
import gfx.Screen;
import map.Level;
import map.tile.TileCoordinate;

public class GameDriver extends Canvas implements Runnable {
	
	private static final long serialVersionUID = 1L;
	public final int WIDTH = 640;
	public final int HEIGHT = WIDTH / 16 * 9;
	public final int SCALE = 2;
	
	public static Level currentLevel;
	
	private Thread gameThread;
	private boolean isRunning = false;
	
	private BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
	private int[] pixelField = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
	private Screen screen;
	
	private Keyboard keyboard;
	
	public JFrame gameFrame;
	
	private Player player;

	public GameDriver() {
		Dimension windowSize = new Dimension(SCALE * WIDTH, SCALE * HEIGHT);
		
		screen = new Screen(WIDTH, HEIGHT);
		
		keyboard = new Keyboard();
		addKeyListener(keyboard);
		
		currentLevel = Level.bigMap;
		
		TileCoordinate bigSpawn = new TileCoordinate(132, 236);
		TileCoordinate testSpawn = new TileCoordinate(8, 8);
		player = new Player(bigSpawn.getX(), bigSpawn.getY(), keyboard);
		
		gameFrame = new JFrame();
		gameFrame.setPreferredSize(windowSize);
		gameFrame.setResizable(false);
		gameFrame.setTitle("Game 1 Test 1 | ");
		gameFrame.add(this);
		gameFrame.pack();
		gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gameFrame.setLocationRelativeTo(null);
		gameFrame.setVisible(true);
		requestFocus();
	}
	
	public synchronized void start() {
		gameThread = new Thread(this, "Display");
		gameThread.start();
		isRunning = true;
	}
	
	public synchronized void stop() {
		try {
			gameThread.join();
		} catch(InterruptedException e) {
			System.out.println("InterruptedException! Printing stack trace:");
			e.printStackTrace();
		}
		isRunning = false;
	}
	
	public void run() {
		//code here acts as a clock to ensure that the game is run at 60fps
		long lastTime = System.nanoTime();
		long timer = System.currentTimeMillis();
		final double ns = 1000000000.0 / 60.0; //divide by target framerate
		double delta = 0;
		int frames = 0;
		int updates = 0;
		
		while(isRunning) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			
			while(delta >= 1) {
				update();
				updates++;
				delta--;
			}
			render();
			frames++;
			
			if((System.currentTimeMillis() - timer) > 1000) {
				timer += 1000;
				gameFrame.setTitle("Game 1 Test 1 | " + frames + " FPS");
				frames = 0;
				updates = 0;
			}
		}
	}
	
	public void update() {
		keyboard.update();
		player.update();
	}
	
	public void render() {
		BufferStrategy bs = getBufferStrategy();
		if(bs == null) {
			createBufferStrategy(3);
			return;
		}
		
		screen.clear();
		
		int xScroll = player.x - screen.width / 2;
		int yScroll = player.y - screen.height / 2;
		currentLevel.render(xScroll, yScroll, screen);
		player.render(screen);
		
		for(int x = 0; x < pixelField.length; x++) {
			pixelField[x] = screen.pixelField[x];
		}
		
		Graphics g = bs.getDrawGraphics();
		
		g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
		
		g.dispose();
		bs.show();
	}
	
	public static void main(String[] args) {
		GameDriver game = new GameDriver();
		
		game.start();
	}

}
