package map.tile;

import gfx.Screen;
import gfx.Sprite;

public class Tile {
	
	public int x;
	public int y;
	
	public Sprite sprite;
	
	public boolean solid;
	
	public static Tile grass = new Tile(Sprite.grass, false);
	public static Tile tallGrass = new Tile(Sprite.tallGrass, false);
	public static Tile flower = new Tile(Sprite.flower, false);
	public static Tile brick = new Tile(Sprite.brick, true);
	public static Tile roof = new Tile(Sprite.roof, true);
	public static Tile doorBottom = new Tile(Sprite.doorBottom, true);
	public static Tile doorTop = new Tile(Sprite.doorTop, true);
	public static Tile cobble = new Tile(Sprite.cobble, false);
	public static Tile window = new Tile(Sprite.window, true);
	public static Tile water = new Tile(Sprite.water, true);
	public static Tile grassPath = new Tile(Sprite.grassPath, false);
	public static Tile sand = new Tile(Sprite.sand, false);
	public static Tile voidTile = new Tile(Sprite.voidSprite, true);
	
	public Tile(Sprite sprite, boolean solid) {
		this.sprite = sprite;
		this.solid = solid;
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderTile(x * 32, y * 32, this);
	}
	
	public boolean isSolid() {
		return solid;
	}

}
