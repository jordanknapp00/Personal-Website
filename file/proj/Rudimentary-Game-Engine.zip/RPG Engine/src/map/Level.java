package map;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

import gfx.Screen;
import map.tile.Tile;

public class Level {
	
	private int width;
	private int height;
	private int[] tiles;
	
	private final Random random = new Random();
	
	public static Level testMap = new Level("res/map/testmap.png");
	public static Level bigMap = new Level("res/map/bigmap.png");
	
	public Level(int width, int height) {
		this.width = width;
		this.height = height;
		tiles = new int[width * height];
		
		generateLevel();
	}
	
	public Level(String path) {
		loadLevel(path);
	}
	
	private void generateLevel() {
		for(int at = 0; at < tiles.length; at++) {
			tiles[at] = random.nextInt(3);
		}
	}
	
	private void loadLevel(String path) {
		try {
			BufferedImage image = ImageIO.read(new File(path));
			width = image.getWidth();
			height = image.getHeight();
			tiles = new int[width * height];
			int[] temp = new int[width * height];
			image.getRGB(0, 0, width, height, temp, 0, width);
			
			//0xFF008000 = 0
			//0xFF015400 = 1
			//0xFF8AA0FF = 2
			//0xFFA17257 = 3
			//0xFF813B11 = 4
			//0xFF3B2A20 = 5
			//0xFF30221A = 6
			//0xFF808080 = 7
			//0xFF00A4D9 = 8
			//0xFF0C44B0 = 9
			//0xFF996A32 = 10
			//0xFFFFB266 = 11
			for(int at = 0; at < temp.length; at++) {
				switch(temp[at]) {
					case 0xFF008000:
						tiles[at] = 0;
						break;
					case 0xFF015400:
						tiles[at] = 1;
						break;
					case 0xFF8AA0FF:
						tiles[at] = 2;
						break;
					case 0xFFA17257:
						tiles[at] = 3;
						break;
					case 0xFF813B11:
						tiles[at] = 4;
						break;
					case 0xFFFFC838:
						tiles[at] = 5;
						break;
					case 0xFF30221A:
						tiles[at] = 6;
						break;
					case 0xFF808080:
						tiles[at] = 7;
						break;
					case 0xFF45B5D9:
						tiles[at] = 8;
						break;
					case 0xFF0C44B0:
						tiles[at] = 9;
						break;
					case 0xFF996A32:
						tiles[at] = 10;
						break;
					case 0xFFFFB266:
						tiles[at] = 11;
						break;
					default:
						tiles[at] = -1;
				}
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void update() {
		
	}
	
	public void render(int x, int y, Screen screen) {
		screen.setOffset(x, y);
		
		int x0 = x / 32;
		int y0 = y / 32;
		int x1 = (x + screen.width + 32) / 32;
		int y1 = (y + screen.height + 32) / 32;
		
		for(int currY = y0; currY < y1; currY++) {
			for(int currX = x0; currX < x1; currX++) {
				getTile(currX, currY).render(currX, currY, screen);
			}
		}
	}
	
	public Tile getTile(int x, int y) {
		if(x < 0 || y < 0 || x >= width || y >= height) {
			return Tile.voidTile;
		}
		
		switch(tiles[x + y * width]) {
			case 0:
				return Tile.grass;
			case 1:
				return Tile.tallGrass;
			case 2:
				return Tile.flower;
			case 3:
				return Tile.brick;
			case 4:
				return Tile.roof;
			case 5:
				return Tile.doorBottom;
			case 6:
				return Tile.doorTop;
			case 7:
				return Tile.cobble;
			case 8:
				return Tile.window;
			case 9:
				return Tile.water;
			case 10:
				return Tile.grassPath;
			case 11:
				return Tile.sand;
			default:
				return Tile.voidTile;
		}
	}
	
	private void time() {
		
	}
	
}
