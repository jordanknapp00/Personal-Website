package entity.mob;

import game.Keyboard;
import gfx.Screen;
import gfx.Sprite;

public class Player extends Mob {
	
	private Keyboard input;
	
	private Sprite sprite0;
	private Sprite sprite1;
	
	private int anim = 0;
	private boolean walking = false;
	
	public Player(int x, int y, Keyboard input) {
		this.x = x;
		this.y = y;
		this.input = input;
	}
	
	public Player(Keyboard input) {
		this.input = input;
	}
	
	public void update() {
		int xChange = 0;
		int yChange = 0;
		
		if(anim++ > 39) {
			anim = 0;
		}
		
		int speed = 2;
		if(input.shift) {
			speed = 4;
			anim++;
		}
		
		if(input.up) {
			yChange -= speed;
		}
		if(input.down) {
			yChange += speed;
		}
		if(input.left) {
			xChange -= speed;
		}
		if(input.right) {
			xChange += speed;
		}
		
		if(xChange != 0 || yChange != 0) {
			move(xChange, yChange);
			walking = true;
		}
		else {
			walking = false;
		}
	}
	
	public void render(Screen screen) {
		//if it ever seems off-center (like when the game is more finished), try:
		//int yy = y - 32;
		//then replace the y in each render call with yy
		
		boolean xFlip = false;
		
		int walkCycle = 1;
		if(walking) {
			if(anim < 10) {
				walkCycle = 1;
			}
			else if(anim > 9 && anim < 20) {
				walkCycle = 2;
			}
			else if(anim > 19 && anim < 30) {
				walkCycle = 3;
			}
			else {
				walkCycle = 4;
			}
		}
		
		if(dir == 0) {
			if(walkCycle == 2) {
				sprite0 = Sprite.playerNorthTopf2;
				sprite1 = Sprite.playerNorthBotf2;
			}
			else if(walkCycle == 4) {
				sprite0 = Sprite.playerNorthTopf4;
				sprite1 = Sprite.playerNorthBotf4;
			}
			else {
				sprite0 = Sprite.playerNorthTopf13;
				sprite1 = Sprite.playerNorthBotf13;
			}
		}
		else if(dir == 1 || dir == 3) {
			if(walkCycle == 2) {
				sprite0 = Sprite.playerSideTopf2;
				sprite1 = Sprite.playerSideBotf2;
			}
			else if(walkCycle == 4) {
				sprite0 = Sprite.playerSideTopf4;
				sprite1 = Sprite.playerSideBotf4;
			}
			else {
				sprite0 = Sprite.playerSideTopf13;
				sprite1 = Sprite.playerSideBotf13;
			}
			
			if(dir == 3) {
				xFlip = true;
			}
		}
		else if(dir == 2) {
			if(walkCycle == 2) {
				sprite0 = Sprite.playerSouthTopf2;
				sprite1 = Sprite.playerSouthBotf2;
			}
			else if(walkCycle == 4) {
				sprite0 = Sprite.playerSouthTopf4;
				sprite1 = Sprite.playerSouthBotf4;
			}
			else {
				sprite0 = Sprite.playerSouthTopf13;
				sprite1 = Sprite.playerSouthBotf13;
			}
		}
		
		screen.renderPlayer(x, y, sprite0, xFlip, false);
		screen.renderPlayer(x, y + 32, sprite1, xFlip, false);
	}

}
