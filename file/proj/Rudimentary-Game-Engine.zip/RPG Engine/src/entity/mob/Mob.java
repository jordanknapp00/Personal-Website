package entity.mob;

import entity.Entity;
import game.GameDriver;
import gfx.Sprite;

public abstract class Mob extends Entity {
	
	protected Sprite sprite;
	protected int dir;
	protected boolean isMoving;
	
	public void move(int xChange, int yChange) {
		if(xChange > 0) {
			dir = 1;
		}
		else if(xChange < 0) {
			dir = 3;
		}
		
		if(yChange > 0) {
			dir = 2;
		}
		else if(yChange < 0) {
			dir = 0;
		}
		
		if(!collision((x + xChange) / 32, (y + 32 + yChange) / 32)) {
			x += xChange;
			y += yChange;
		}
	}
	
	public void update() {
		
	}
	
	private boolean collision(int nextX, int nextY) {
		if(GameDriver.currentLevel.getTile(nextX, nextY).isSolid()) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void render() {
		
	}

}
