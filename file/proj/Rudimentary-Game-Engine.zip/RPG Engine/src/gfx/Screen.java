package gfx;

import java.util.Random;

import entity.mob.Player;
import map.tile.Tile;

public class Screen {
	
	public final int MAP_LENGTH = 64;
	
	public int width;
	public int height;
	
	public int xOffset;
	public int yOffset;
	
	public int[] pixelField;
	public int[] tiles;
	
	private Random random = new Random();
	
	public Screen(int width, int height) {
		this.width = width;
		this.height = height;
		
		pixelField = new int[width * height];
		tiles = new int[MAP_LENGTH * MAP_LENGTH];
	}
	
	public void renderTile(int xPos, int yPos, Tile tile) {
		xPos -= xOffset;
		yPos -= yOffset;
		
		for(int y = 0; y < tile.sprite.SIZE; y++) {
			int yAbsolute = y + yPos;
			for(int x = 0; x < tile.sprite.SIZE; x++) {
				int xAbsolute = x + xPos;
				
				if(xAbsolute < -tile.sprite.SIZE || xAbsolute >= width || yAbsolute < -tile.sprite.SIZE || yAbsolute >= height) {
					break;
				}
				
				if(xAbsolute < 0) {
					xAbsolute = 0;
				}
				if(yAbsolute < 0) {
					yAbsolute = 0;
				}
				
				pixelField[xAbsolute + yAbsolute * width] = tile.sprite.pixels[x + y * tile.sprite.SIZE];
			}
		}	
	}
	
	public void renderPlayer(int xPos, int yPos, Sprite sprite, boolean xFlip, boolean yFlip) {
		xPos -= xOffset;
		yPos -= yOffset;
		
		for(int y = 0; y < sprite.SIZE; y++) {
			int yAbsolute = y + yPos;
			
			int yFlipped = y;
			if(yFlip) {
				yFlipped = (sprite.SIZE - 1) - y;
			}
			
			for(int x = 0; x < sprite.SIZE; x++) {
				int xAbsolute = x + xPos;
				
				if(xAbsolute < -sprite.SIZE || xAbsolute >= width || yAbsolute < -sprite.SIZE || yAbsolute >= height) {
					break;
				}
				
				if(xAbsolute < 0) {
					xAbsolute = 0;
				}
				if(yAbsolute < 0) {
					yAbsolute = 0;
				}
				
				int xFlipped = x;
				if(xFlip) {
					xFlipped = (sprite.SIZE - 1) - x;
				}
				
				int color = sprite.pixels[xFlipped + yFlipped * sprite.SIZE];
				
				if(color != 0x00000000) {
					pixelField[xAbsolute + yAbsolute * width] = sprite.pixels[xFlipped + yFlipped * sprite.SIZE];
				}
			}
		}
	}
	
	public void setOffset(int xOff, int yOff) {
		xOffset = xOff;
		yOffset = yOff;
	}
	
	public void clear() {
		for(int x = 0; x < pixelField.length; x++) {
			pixelField[x] = 0x000000;
		}
	}

}
