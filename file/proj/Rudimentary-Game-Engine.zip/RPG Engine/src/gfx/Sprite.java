package gfx;

import java.util.Arrays;

import gfx.Spritesheet;

public class Sprite {
	
	public final int SIZE;
	private int x;
	private int y;
	public int[] pixels;
	
	private Spritesheet sheet;
	
	public static Sprite grass = new Sprite(32, 0, 0, Spritesheet.tiles);
	public static Sprite tallGrass = new Sprite(32, 1, 0, Spritesheet.tiles);
	public static Sprite flower = new Sprite(32, 2, 0, Spritesheet.tiles);
	public static Sprite brick = new Sprite(32, 3, 0, Spritesheet.tiles);
	public static Sprite roof = new Sprite(32, 4, 0, Spritesheet.tiles);
	public static Sprite doorBottom = new Sprite(32, 5, 0, Spritesheet.tiles);
	public static Sprite doorTop = new Sprite(32, 6, 0, Spritesheet.tiles);
	public static Sprite cobble = new Sprite(32, 7, 0, Spritesheet.tiles);
	public static Sprite window = new Sprite(32, 0, 1, Spritesheet.tiles);
	public static Sprite water = new Sprite(32, 1, 1, Spritesheet.tiles);
	public static Sprite grassPath = new Sprite(32, 2, 1, Spritesheet.tiles);
	public static Sprite sand = new Sprite(32, 3, 1, Spritesheet.tiles);
	public static Sprite voidSprite = new Sprite(32, 0x000000);
	
	public static Sprite playerSouthTopf13 = new Sprite(32, 0, 0, Spritesheet.sprites);
	public static Sprite playerSouthBotf13 = new Sprite(32, 0, 1, Spritesheet.sprites);
	public static Sprite playerSouthTopf2 = new Sprite(32, 1, 0, Spritesheet.sprites);
	public static Sprite playerSouthBotf2 = new Sprite(32, 1, 1, Spritesheet.sprites);
	public static Sprite playerSouthTopf4 = new Sprite(32, 2, 0, Spritesheet.sprites);
	public static Sprite playerSouthBotf4 = new Sprite(32, 2, 1, Spritesheet.sprites);
	
	public static Sprite playerSideTopf13 = new Sprite(32, 0, 2, Spritesheet.sprites);
	public static Sprite playerSideBotf13 = new Sprite(32, 0, 3, Spritesheet.sprites);
	public static Sprite playerSideTopf2 = new Sprite(32, 1, 2, Spritesheet.sprites);
	public static Sprite playerSideBotf2 = new Sprite(32, 1, 3, Spritesheet.sprites);
	public static Sprite playerSideTopf4 = new Sprite(32, 2, 2, Spritesheet.sprites);
	public static Sprite playerSideBotf4 = new Sprite(32, 2, 3, Spritesheet.sprites);
	
	public static Sprite playerNorthTopf13 = new Sprite(32, 0, 4, Spritesheet.sprites);
	public static Sprite playerNorthBotf13 = new Sprite(32, 0, 5, Spritesheet.sprites);
	public static Sprite playerNorthTopf2 = new Sprite(32, 1, 4, Spritesheet.sprites);
	public static Sprite playerNorthBotf2 = new Sprite(32, 1, 5, Spritesheet.sprites);
	public static Sprite playerNorthTopf4 = new Sprite(32, 2, 4, Spritesheet.sprites);
	public static Sprite playerNorthBotf4 = new Sprite(32, 2, 5, Spritesheet.sprites);
	
	public Sprite(int size, int x, int y, Spritesheet sheet) {
		SIZE = size;
		this.x = x * size; //allows us to just use coordinates for finding sprites, rather than pixels
		this.y = y * size; //i.e. sprite (5, 3) instead of figuring out what pixel it starts at
		this.sheet = sheet;
		
		pixels = new int[SIZE * SIZE];
		loadSprite();
	}
	
	public Sprite(int size, int color) {
		SIZE = size;
		pixels = new int[SIZE * SIZE];
		Arrays.fill(pixels, color);
	}
	
	private void loadSprite() {
		for(int y = 0; y < SIZE; y++) {
			for(int x = 0; x < SIZE; x++) {
				pixels[x + y * SIZE] = sheet.pixels[(x + this.x) + (y + this.y) * sheet.SIZE];
			}
		}
	}
}
