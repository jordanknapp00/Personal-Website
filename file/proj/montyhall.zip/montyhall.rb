play_again = "y"
game = 0
total_won = 0
total_switched  = 0
won_outright = 0

while play_again == "y"
    system("clear")
    game += 1
    door = rand(1..3)

    puts "Game #{game}:"
    puts "There are three doors. One of them has a brand new car. The others, nothing."
    picked = 0
    while picked < 1 || picked > 3
        print "Which door do you want? "
        picked = gets.chomp.to_i
    end

    #logic to determine which door to reveal:
    #if the chosen door and the door with the reward are different, then the
    #third door is selected.
    #
    #if the chosen door and the reward door are the same, just pick one of the
    #other two. default to 1 of the correct door was 2 or 3; if correct door was
    #1, then we'll just pick 2 as the reveal door.
    if door == 1 && picked == 2
        reveal = 3
    elsif door == 1 && picked == 3
        reveal = 2
    elsif door == 2 && picked == 1
        reveal = 3
    elsif door == 2 && picked == 3
        reveal = 1
    elsif door == 3 && picked == 1
        reveal = 2
    elsif door == 1 && picked == 1
        reveal = 2
    else
        reveal = 1
    end

    puts "I can now reveal to you that behind door number #{reveal} is nothing."
    switched = ""
    while switched != "y" && switched != "n"
        print "Will you switch to the other door? (y/n) "
        switched = gets.chomp
    end

    #similar logic to before to determine which door you end up with when you switch
    #doors. in this case, we know that picked and reveal cannot be the same door, so
    #we do not need to check those cases
    if switched == "y"
        if picked == 1 && reveal == 2
            picked = 3
        elsif picked == 1 && reveal == 3
            picked = 2
        elsif picked == 2 && reveal == 1
            picked = 3
        elsif picked == 2 && reveal == 3
            picked = 1
        elsif picked == 3 && reveal == 1
            picked = 2
        else
            picked = 1
        end

        puts "You've switched your choice to door number #{picked}."
        total_switched  += 1
    end

    if picked == door
        total_won += 1
        puts "Congratulations, you've won a brand new car!"

        if switched == "n"
            won_outright += 1
        end
    else
        puts "Sorry, looks like you didn't win anything this time."
        puts "Better luck next time!"
    end
    puts ""
    puts "Statistics:"
    puts "You've won #{total_won} times."
    puts "You've switched #{total_switched} times."
    puts "You've won outright (guessed right from the start) #{won_outright} times."
    puts ""
    puts "You've won #{(total_won / game.to_f) * 100}% of games."
    puts "You've switched on #{(total_switched / game.to_f) * 100}% of games."
    puts "You've won #{(total_won / total_switched.to_f) * 100}% of games that you switched."

    play_again = ""
    while play_again != "y" && play_again != "n"
        print "Play again? (y/n)"
        play_again = gets.chomp
    end
end