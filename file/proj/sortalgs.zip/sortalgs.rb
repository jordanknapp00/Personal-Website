def bubbleSort(arr)
    for i in (arr.length - 1).downto(1)
        for j in 0..(i-1)
            puts "comparing #{j} to #{j + 1}."
            if arr[j] > arr[j+1]
                swap(arr, j, j+1)
            end
        end
    end

    return arr
end

def modifiedBubbleSort(arr)
    i = arr.length - 2
    while i >= 0
        t = 0
        for j in 0..i
            puts "comparing #{j} to #{j + 1}."
            if arr[j] > arr[j+1]
                swap(arr, j, j+1)
                t = j
            end
        end
        i = t - 1
    end

    return arr
end

def selectionSort(arr)
    for i in (arr.length - 1).downto(1)
        k = 0
        for j in 1..i
            if arr[j] > arr[k]
                k = j
            end
        end
        swap(arr, i, k)
    end

    return arr
end

def insertionSort(arr)
    for i in 1..(arr.length - 1)
        t = arr[i]
        j = i - 1
        while (j >= 0) && (arr[j] > t)
            arr[j+1] = arr[j]
            j = j - 1
        end
        arr[j+1] = t
    end

    return arr
end

def mergeSort(arr)
    n = arr.length - 1
    if arr.length == 1
        return arr
    end

    left = mergeSort(arr[0..(n/2)])
    right = mergeSort(arr[((n/2)+1)..n])

    return merge(left, right)
end

def merge(left, right)
    leftLength = left.length
    rightLength = right.length
    returnArr = Array.new

    i = 0
    j = 0
    k = 0
    while (i < leftLength) && (j < rightLength)
        if left[i] < right[j]
            returnArr[k] = left[i]
            i = i + 1
        else
            returnArr[k] = right[j]
            j = j + 1
        end
        k = k + 1
    end

    while i < leftLength
        returnArr[k] = left[i]
        i = i + 1
        k = k + 1
    end

    while j < rightLength
        returnArr[k] = right[j]
        j = j + 1
        k = k + 1
    end

    return returnArr
end

def heapSort(arr)
    buildMaxHeap(arr)

    for i in (arr.length - 1).downto(1)
        swap(arr, 0, i)
        new_heap = maxHeapify(arr[0...i], 0)
        arr = new_heap + arr[i...(arr.length)]
    end

    return arr
end

def buildMaxHeap(arr)
    for j in ((arr.length - 1)/2).downto(0)
        maxHeapify(arr, j)
    end

    return arr
end

def maxHeapify(arr, i)
    left = (i * 2) + 1
    right = (i * 2) + 2
    comparisons = 0

    if (left <= (arr.length - 1)) && (arr[left] > arr[i])
        largest = left
    else
        largest = i
    end

    if (right <= (arr.length - 1)) && (arr[right] > arr[largest])
        largest = right
    end

    if largest != i
        swap(arr, i, largest)
        maxHeapify(arr, largest)
    end

    return arr
end

def swap(arr, elm1, elm2)
    arr[elm1], arr[elm2] = arr[elm2], arr[elm1]
end

def maxVal(val1, val2)
    if val1 > val2
        return val1
    else
        return val2
    end
end

def maxContigSubSum(arr)
    max = 0

    for i in 0..(arr.length - 1)
        for j in i..(arr.length - 1)
            sum = 0
            for k in i..j
                sum = sum + arr[k]
            end
            max = maxVal(max, sum)
        end
    end

    return max
end

def kadaneAlg(arr)
    sum = 0
    max = 0

    for i in 1..(arr.length - 1)
        sum = maxVal(sum + arr[i], 0)
        max = maxVal(max, sum)
    end

    return max
end

def quickSort(arr)
    quickSortHelper(arr, 0, arr.length - 1)
end

def quickSortHelper(arr, p, r)
    if p < r
        q = partition(arr, p, r)
        quickSortHelper(arr, p, q - 1)
        quickSortHelper(arr, q + 1, r)
    end

    return arr
end

def partition(arr, p, r)
    x = arr[r]
    i = p - 1

    for j in p..(r - 1)
        if arr[j] <= x
            i += 1
            swap(arr, i, j)
        end
    end
    swap(arr, i + 1, r)
    return i + 1
end